package bee.happy.inholland.nl.servlet;

public class BeeServletRequestAddCommand implements BeeServletRequestCommand{
	DBCommandReceiver receiver;
	/*
	private final ActionType actionType = ActionType.ADD;

	@Override
	public ActionType getType() {
		return actionType;
	}

	@Override
	public void execute() {
		receiver.add();
	}
	*/

}
