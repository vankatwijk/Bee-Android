package bee.happy.inholland.nl.servlet;

public class DBCommandReceiver {
	
	public int add(){
		System.out.println("Adding to DB");
		return 0;
	}

	public int delete(){
		System.out.println("Deleting from DB");
		return 0;
	}

}
