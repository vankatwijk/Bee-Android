package bee.happy.inholland.nl.commands;

public class SelectCommand implements BeeCommand{
	private final BeeCommandType type = BeeCommandType.SELECT;
	private String className;

	/**
	 * Constructor, creates command to select everything from the class
	 * @param className
	 */
	public SelectCommand(String className) {
		super();
		this.className = className;
	}
	

	public String getClassName() {
		return className;
	}


	public void setClassName(String className) {
		this.className = className;
	}


	@Override
	public BeeCommandType getCommandType() {
		return type;
	}
	
	public String toString(){
		return "Select command: [type = "+type+", className = '"+className+"']";
	}

}
