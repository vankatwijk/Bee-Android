package bee.happy.inholland.nl.domainmodel;

public interface BeeObjectInterface {

}
