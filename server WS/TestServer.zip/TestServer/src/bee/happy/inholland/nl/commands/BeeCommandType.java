package bee.happy.inholland.nl.commands;

public enum BeeCommandType {
	PING, CREATE, UPDATE, DELETE, SELECT, AUTH
}
