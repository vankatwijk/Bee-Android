package bee.happy.inholland.nl.servlet;


public class BeeServletRequestDeleteCommand {
	/*DBCommandReceiver receiver;

	public ActionType getType() {
		return BeeServletRequestCommand.ActionType.DELETE;
	}

	public void execute() {
		receiver.delete();
	}
	*/
}
