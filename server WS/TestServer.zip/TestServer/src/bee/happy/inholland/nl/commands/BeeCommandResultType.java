package bee.happy.inholland.nl.commands;

public enum BeeCommandResultType {
	SUCCESS, ERROR
}
