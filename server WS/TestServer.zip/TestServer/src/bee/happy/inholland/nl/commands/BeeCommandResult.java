package bee.happy.inholland.nl.commands;

public interface BeeCommandResult {
	public BeeCommandType getCommandType();
	public BeeCommandResultType getCommandResultType();
}
